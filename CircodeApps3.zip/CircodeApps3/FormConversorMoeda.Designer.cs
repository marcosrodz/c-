﻿namespace CircodeApps3
{
    partial class FormConversorMoeda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormConversorMoeda));
            this.btnconverter = new System.Windows.Forms.Button();
            this.lblValor = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.btnFechar = new System.Windows.Forms.Button();
            this.lblDolar = new System.Windows.Forms.Label();
            this.lblDolar2 = new System.Windows.Forms.Label();
            this.lblLibra = new System.Windows.Forms.Label();
            this.lblLibra2 = new System.Windows.Forms.Label();
            this.lblIene2 = new System.Windows.Forms.Label();
            this.lblIene = new System.Windows.Forms.Label();
            this.lblEuro2 = new System.Windows.Forms.Label();
            this.lblEuro = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnconverter
            // 
            this.btnconverter.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnconverter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnconverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnconverter.ForeColor = System.Drawing.Color.Black;
            this.btnconverter.Location = new System.Drawing.Point(570, 61);
            this.btnconverter.Name = "btnconverter";
            this.btnconverter.Size = new System.Drawing.Size(200, 55);
            this.btnconverter.TabIndex = 0;
            this.btnconverter.Text = "Converter";
            this.btnconverter.UseVisualStyleBackColor = false;
            this.btnconverter.Click += new System.EventHandler(this.btnconverter_Click);
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(45, 69);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(200, 24);
            this.lblValor.TabIndex = 1;
            this.lblValor.Text = "Digite um valor (R$):";
            // 
            // txtValor
            // 
            this.txtValor.BackColor = System.Drawing.Color.White;
            this.txtValor.Location = new System.Drawing.Point(49, 96);
            this.txtValor.Name = "txtValor";
            this.txtValor.Size = new System.Drawing.Size(213, 20);
            this.txtValor.TabIndex = 2;
            this.txtValor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValor_KeyPress);
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.Color.Red;
            this.btnFechar.Location = new System.Drawing.Point(570, 147);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(200, 55);
            this.btnFechar.TabIndex = 3;
            this.btnFechar.Text = "FECHAR";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // lblDolar
            // 
            this.lblDolar.AutoSize = true;
            this.lblDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDolar.Location = new System.Drawing.Point(46, 235);
            this.lblDolar.Name = "lblDolar";
            this.lblDolar.Size = new System.Drawing.Size(80, 16);
            this.lblDolar.TabIndex = 4;
            this.lblDolar.Text = "Dolar ( $ ):";
            // 
            // lblDolar2
            // 
            this.lblDolar2.AutoSize = true;
            this.lblDolar2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDolar2.Location = new System.Drawing.Point(195, 235);
            this.lblDolar2.Name = "lblDolar2";
            this.lblDolar2.Size = new System.Drawing.Size(0, 16);
            this.lblDolar2.TabIndex = 5;
            // 
            // lblLibra
            // 
            this.lblLibra.AutoSize = true;
            this.lblLibra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLibra.Location = new System.Drawing.Point(46, 284);
            this.lblLibra.Name = "lblLibra";
            this.lblLibra.Size = new System.Drawing.Size(85, 16);
            this.lblLibra.TabIndex = 6;
            this.lblLibra.Text = "Libras ( £ ):";
            // 
            // lblLibra2
            // 
            this.lblLibra2.AutoSize = true;
            this.lblLibra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLibra2.Location = new System.Drawing.Point(195, 284);
            this.lblLibra2.Name = "lblLibra2";
            this.lblLibra2.Size = new System.Drawing.Size(0, 16);
            this.lblLibra2.TabIndex = 7;
            // 
            // lblIene2
            // 
            this.lblIene2.AutoSize = true;
            this.lblIene2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIene2.Location = new System.Drawing.Point(195, 377);
            this.lblIene2.Name = "lblIene2";
            this.lblIene2.Size = new System.Drawing.Size(0, 16);
            this.lblIene2.TabIndex = 11;
            // 
            // lblIene
            // 
            this.lblIene.AutoSize = true;
            this.lblIene.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIene.Location = new System.Drawing.Point(46, 377);
            this.lblIene.Name = "lblIene";
            this.lblIene.Size = new System.Drawing.Size(78, 16);
            this.lblIene.TabIndex = 10;
            this.lblIene.Text = "Yene ( ¥ ):";
            // 
            // lblEuro2
            // 
            this.lblEuro2.AutoSize = true;
            this.lblEuro2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEuro2.Location = new System.Drawing.Point(195, 328);
            this.lblEuro2.Name = "lblEuro2";
            this.lblEuro2.Size = new System.Drawing.Size(0, 16);
            this.lblEuro2.TabIndex = 9;
            this.lblEuro2.Click += new System.EventHandler(this.lblEuro2_Click);
            // 
            // lblEuro
            // 
            this.lblEuro.AutoSize = true;
            this.lblEuro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEuro.Location = new System.Drawing.Point(46, 328);
            this.lblEuro.Name = "lblEuro";
            this.lblEuro.Size = new System.Drawing.Size(74, 16);
            this.lblEuro.TabIndex = 8;
            this.lblEuro.Text = "Euro ( € ):";
            // 
            // FormConversorMoeda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblIene2);
            this.Controls.Add(this.lblIene);
            this.Controls.Add(this.lblEuro2);
            this.Controls.Add(this.lblEuro);
            this.Controls.Add(this.lblLibra2);
            this.Controls.Add(this.lblLibra);
            this.Controls.Add(this.lblDolar2);
            this.Controls.Add(this.lblDolar);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.txtValor);
            this.Controls.Add(this.lblValor);
            this.Controls.Add(this.btnconverter);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormConversorMoeda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Conversor de moeda";
            this.Load += new System.EventHandler(this.FormConversorMoeda_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnconverter;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Label lblDolar;
        private System.Windows.Forms.Label lblDolar2;
        private System.Windows.Forms.Label lblLibra;
        private System.Windows.Forms.Label lblLibra2;
        private System.Windows.Forms.Label lblIene2;
        private System.Windows.Forms.Label lblIene;
        private System.Windows.Forms.Label lblEuro2;
        private System.Windows.Forms.Label lblEuro;
    }
}